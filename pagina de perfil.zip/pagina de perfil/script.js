// adiciona um evento de clique para os links do menu de navegação
const navLinks = document.querySelectorAll('nav a');
navLinks.forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const sectionId = link.getAttribute('href');
    const section = document.querySelector(sectionId);
    section.scrollIntoView({ behavior: 'smooth' });
  });
});

// adiciona um efeito de rolagem para a seção principal
const mainSection = document.querySelector('main');
window.addEventListener('scroll', () => {
  const top = mainSection.getBoundingClientRect().top;
  if (top < window.innerHeight * 0.8) {
    mainSection.classList.add('visible');
  }
});
